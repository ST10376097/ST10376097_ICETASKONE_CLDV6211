﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MvcShoe.Data;
using System;
using System.Linq;

namespace MvcShoe.Models
{ 
       
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new MvcShoeContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<MvcShoeContext>>()))
            {
                // Look for any movies.
                if (context.Shoe.Any())
                {
                    return;   // DB has been seeded
                }
                context.Shoe.AddRange(
                    new Shoe
                    {
                        Name = "Converse",
                        Brand = "All Stars",
                        Size = 5,
                        Price = 700M,
                    },
                    new Shoe
                    {
                        Name = "Stiletto Heels",
                        Brand = "Aldo",
                        Size = 3,
                        Price = 750M,
                    },
                    new Shoe
                    {
                        Name = "Air force 1",
                        Brand = "Nike",
                        Size = 4,
                        Price = 1350M,
                    },
                    new Shoe
                    {
                        Name = "Vans Old Skool",
                        Brand = "Vans",
                        Size = 8,
                        Price = 700M,
                    }
                ) ; 
                context.SaveChanges();
            }
        }
    }
}

